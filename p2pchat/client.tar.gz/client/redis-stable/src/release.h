#define REDIS_GIT_SHA1 "ab412ade"
#define REDIS_GIT_DIRTY "3"
#define REDIS_BUILD_ID "ht6-ThinkPad-L440-1407477444"
